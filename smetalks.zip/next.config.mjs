/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['http://smebusinessmagazine.test/'], // Replace with your actual Drupal domain
    },
};

export default nextConfig;
